package com.fmotech.chess;

import java.time.LocalDateTime;

import static com.fmotech.chess.BitOperations.highestBit;
import static com.fmotech.chess.BitOperations.highestBitPosition;
import static com.fmotech.chess.BitOperations.lowestBit;
import static com.fmotech.chess.BitOperations.lowestBitPosition;
import static com.fmotech.chess.BitOperations.nextHighestBit;
import static com.fmotech.chess.BitOperations.nextLowestBit;
import static com.fmotech.chess.Board.BISHOP;
import static com.fmotech.chess.Board.KING;
import static com.fmotech.chess.Board.KNIGHT;
import static com.fmotech.chess.Board.MOVE_CAST_H;
import static com.fmotech.chess.Board.MOVE_CAST_L;
import static com.fmotech.chess.Board.MOVE_EP;
import static com.fmotech.chess.Board.MOVE_EP_CAP;
import static com.fmotech.chess.Board.MOVE_PROMO;
import static com.fmotech.chess.Board.PAWN;
import static com.fmotech.chess.Board.QUEEN;
import static com.fmotech.chess.Board.ROCK;
import static com.fmotech.chess.Board.SPECIAL;
import static com.fmotech.chess.MoveTables.BISHOP_HIGH_TABLE;
import static com.fmotech.chess.MoveTables.BISHOP_LOW_TABLE;
import static com.fmotech.chess.MoveTables.KING_TABLE;
import static com.fmotech.chess.MoveTables.KNIGHT_TABLE;
import static com.fmotech.chess.MoveTables.PAWN_ATTACK_TABLE;
import static com.fmotech.chess.MoveTables.ROCK_HIGH_TABLE;
import static com.fmotech.chess.MoveTables.ROCK_LOW_TABLE;
import static java.time.LocalDateTime.now;
import static java.time.temporal.ChronoUnit.MILLIS;
import static org.junit.Assert.assertEquals;

public class MoveGenerator {

    private static final long PAWN_RANK = 0x000000000000ff00L;
    private static final long RANK_7 = 0x00FF0000_00000000L;

    public static void main(String[] args) {
        execute(Board.fen("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"),
                20, 400, 8_902, 197_281, 4_865_609, 119_060_324, 3_195_901_860L);
        execute(Board.fen("r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq -"),
                48, 2_039, 97_862, 4_085_603, 193_690_690, 8_031_647_685L);
        execute(Board.fen("8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - -"),
                14, 191, 2_812, 43_238, 674_624, 11_030_083, 178_633_661);
        execute(Board.fen("r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1"),
                6, 264, 9_467, 422_333, 15_833_292, 706_045_033);
        execute(Board.fen("rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8"),
                44, 1_486, 62_379, 2_103_487, 89_941_194, 3_048_196_529L);
        execute(Board.fen("r4rk1/1pp1qppp/p1np1n2/2b1p1B1/2B1P1b1/P1NP1N2/1PP1QPPP/R4RK1 w - - 0 10"),
                46, 2_079, 89_890, 3_894_594, 164_075_551, 6_923_051_137L);
        execute(Board.fen("8/2p5/2Kp4/1P3k1r/1R3p2/8/4P1P1/8 b - - 0 1"),
                16, 269, 4590, 80_683, 1_426_460, 25_913_670, 465_252_415);
    }

    private static void execute(Board board, long... counts) {
        System.out.println(board);
        for (int i = 1; i <= counts.length; i++) {
            LocalDateTime start = now();
            long count = MoveGenerator.countMoves(i, board);
            System.out.printf("%d: %10d in %6d ms\n", i, count, MILLIS.between(start, now()));
            assertEquals(counts[i-1], count);
        }
    }

    public static long countMoves(int level, Board board) {
        if (level == 0) return 1;
        long scenarios = 0;
        int[] moves = board.moves();
        int counter = generateDirtyMoves(board, moves);
        for (int i = 0; i < counter; i++) {
            Board nextBoard = board.move(moves[i]);
            int kingPosition = lowestBitPosition(nextBoard.ownKing());
            if (!isPositionInAttack(nextBoard, kingPosition)) {
                scenarios += countMoves(level - 1, nextBoard.nextTurn());
            }
        }
        return scenarios;
    }

    public static int generateValidMoves(Board board, int[] moves) {
        int counter = generateDirtyMoves(board, moves);
        int index = 0;
        for (int i = 0; i < counter; i++) {
            Board nextBoard = board.move(moves[i]);
            if (isValid(nextBoard)) {
                moves[index++] = moves[i];
            }
        }
        return index;
    }

    public static boolean isValid(Board board) {
        int kingPosition = lowestBitPosition(board.ownKing());
        return !isPositionInAttack(board, kingPosition);
    }

    public static int generateDirtyMoves(Board board, int[] moves) {
        int counter = 0;
        counter = generatePawnMoves(board, counter, moves);
        counter = generateRocksMoves(board, counter, moves);
        counter = generateKnightMoves(board, counter, moves);
        counter = generateBishopsMoves(board, counter, moves);
        counter = generateQueensMoves(board, counter, moves);
        counter = generateKingMoves(board, counter, moves);
        return counter;
    }

    private static int generatePawnMoves(Board board, int counter, int[] moves) {
        long pieces = board.pieces() | board.enPassant();
        long pawns = board.ownPawns();
        while (pawns != 0) {
            long pawn = lowestBit(pawns);
            int srcPos = lowestBitPosition(pawns);
            int promote = (pawn & RANK_7) != 0 ? MOVE_PROMO : 0;
            long next = pawn << 8;//PAWN[pos];
            if ((pieces & next) == 0) {
                int tgtPos = lowestBitPosition(next);
                counter = createPawnMove(moves, counter, srcPos, tgtPos, 0, promote);
                if ((pawn & PAWN_RANK) != 0) {
                    next <<= 8;
                    tgtPos = lowestBitPosition(next);
                    if ((pieces & next) == 0) {
                        counter = createPawnMove(moves, counter, srcPos, tgtPos, 0, MOVE_EP);
                    }
                }
            }
            next = PAWN_ATTACK_TABLE[srcPos];
            while (next != 0) {
                long pawnAttack = lowestBit(next);
                if ((pawnAttack & pieces) != 0 && board.enemy(pawnAttack)) {
                    int tgtPos = lowestBitPosition(next);
                    int capture = board.type(tgtPos, ROCK, SPECIAL);
                    counter = createPawnMove(moves, counter, srcPos, tgtPos, capture, promote);
                }
                next = nextLowestBit(next);
            }
            pawns = nextLowestBit(pawns);
        }
        return counter;
    }

    private static int generateRocksMoves(Board board, int counter, int[] moves) {
        long rocks = board.ownRocks();
        while (rocks != 0) {
            int pos = lowestBitPosition(rocks);
            long mask = generateLinearMoveFor(board, pos, ROCK_HIGH_TABLE, ROCK_LOW_TABLE);
            counter = createMove(moves, counter, board, pos, ROCK, mask);
            rocks = nextLowestBit(rocks);
        }
        return counter;
    }

    private static int generateKnightMoves(Board board, int counter, int[] moves) {
        return generateTargetMoves(board, board.ownKnights(), KNIGHT_TABLE, KNIGHT, counter, moves);
    }

    private static int generateBishopsMoves(Board board, int counter, int[] moves) {
        long bishops = board.ownBishops();
        while (bishops != 0) {
            int pos = lowestBitPosition(bishops);
            long mask = generateLinearMoveFor(board, pos, BISHOP_HIGH_TABLE, BISHOP_LOW_TABLE);
            counter = createMove(moves, counter, board, pos, BISHOP, mask);
            bishops = nextLowestBit(bishops);
        }
        return counter;
    }

    private static int generateQueensMoves(Board board, int counter, int[] moves) {
        long queens = board.ownQueens();
        while (queens != 0) {
            int pos = lowestBitPosition(queens);
            long mask = generateLinearMoveFor(board, pos, ROCK_HIGH_TABLE, ROCK_LOW_TABLE)
                    | generateLinearMoveFor(board, pos, BISHOP_HIGH_TABLE, BISHOP_LOW_TABLE);
            counter = createMove(moves, counter, board, pos, QUEEN, mask);
            queens = nextLowestBit(queens);
        }
        return counter;
    }

    private static int generateKingMoves(Board board, int counter, int[] moves) {
        long king = board.ownKing();
        int kingPos = lowestBitPosition(king);
        counter = generateTargetMoves(board, king, KING_TABLE, KING, counter, moves);
        if (board.castleLow() && !isPositionInAttack(board, kingPos) && !isPositionInAttack(board, kingPos - 1)
                && !isPositionInAttack(board, kingPos - 2)) {
            moves[counter++] = createMove(kingPos, kingPos - 2, KING, 0, MOVE_CAST_L);
        }
        if (board.castleHigh() && !isPositionInAttack(board, kingPos) && !isPositionInAttack(board, kingPos + 1)
                && !isPositionInAttack(board, kingPos + 2)) {
            moves[counter++] = createMove(kingPos, kingPos + 2, KING, 0, MOVE_CAST_H);
        }
        return counter;
    }

    private static long generateLinearMoveFor(Board board, int pos, long[] highTable, long[] lowTable) {
        long pieces = board.pieces();
        long move = 0;
        long next = highTable[pos];
        move |= next;
        next &= pieces;
        while (next != 0) {
            long contact = lowestBit(next);
            int contactPos = lowestBitPosition(contact);
            long mask = ~highTable[contactPos];
            move &= mask;
            if (board.own(contact)) move ^= contact;
            next &= mask;
            next = nextLowestBit(next);
        }
        next = lowTable[pos];
        move |= next;
        next &= pieces;
        while (next != 0) {
            long contact = highestBit(next);
            int contactPos = highestBitPosition(contact);
            long mask = ~lowTable[contactPos];
            move &= mask;
            if (board.own(contact)) move ^= contact;
            next &= mask;
            next = nextHighestBit(next);
        }
        return move;
    }

    private static int generateTargetMoves(Board board, long pieces, long[] table, int srcType, int counter, int[] moves) {
        long mask = ~board.ownPieces();
        while (pieces != 0) {
            int srcPos = lowestBitPosition(pieces);
            counter = createMove(moves, counter, board, srcPos, srcType, table[srcPos] & mask);
            pieces = nextLowestBit(pieces);
        }
        return counter;
    }

    private static int createPawnMove(int[] moves, int counter, int srcPos, int tgtPos, int tgtType, int flags) {
        if (flags == MOVE_PROMO) {
            moves[counter++] = createMove(srcPos, tgtPos, PAWN, tgtType, MOVE_PROMO | QUEEN);
            moves[counter++] = createMove(srcPos, tgtPos, PAWN, tgtType, MOVE_PROMO | ROCK);
            moves[counter++] = createMove(srcPos, tgtPos, PAWN, tgtType, MOVE_PROMO | BISHOP);
            moves[counter++] = createMove(srcPos, tgtPos, PAWN, tgtType, MOVE_PROMO | KNIGHT);
        } else if (tgtType == SPECIAL) {
            moves[counter++] = createMove(srcPos, tgtPos, PAWN, PAWN, MOVE_EP_CAP);
        } else {
            moves[counter++] = createMove(srcPos, tgtPos, PAWN, tgtType, flags);
        }
        return counter;
    }

    private static int createMove(int[] moves, int counter, Board board, int srcPos, int srcType, long mask) {
        long next = mask;
        while (next != 0) {
            int tgtPos = lowestBitPosition(next);
            int tgtType = board.type(tgtPos, ROCK, 0);
            moves[counter++] = createMove(srcPos, tgtPos, srcType, tgtType, 0);
            next = nextLowestBit(next);
        }
        return counter;
    }

    private static int createMove(int srcPos, int tgtPos, int srcType, int tgtType, int flags) {
        return flags << 24 | tgtType << 20 | srcType << 16 | tgtPos << 8 | srcPos;
    }

    public static boolean isPositionInAttack(Board board, int pos) {
        long pieces = board.pieces();
        if ((PAWN_ATTACK_TABLE[pos] & board.enemyPawns()) != 0) return true;
        if ((KNIGHT_TABLE[pos] & board.enemyKnights()) != 0) return true;
        if ((KING_TABLE[pos] & board.enemyKing()) != 0) return true;
        long rocksQueens = board.enemyRocks() | board.enemyQueens();
        if (isPositionInAttackHigh(pos, rocksQueens, pieces, ROCK_HIGH_TABLE)) return true;
        if (isPositionInAttackLow(pos, rocksQueens, pieces, ROCK_LOW_TABLE)) return true;
        long bishopsQueens = board.enemyBishops() | board.enemyQueens();
        if (isPositionInAttackHigh(pos, bishopsQueens, pieces, BISHOP_HIGH_TABLE)) return true;
        if (isPositionInAttackLow(pos, bishopsQueens, pieces, BISHOP_LOW_TABLE)) return true;
        return false;
    }

    private static boolean isPositionInAttackHigh(int pos, long targetPieces, long pieces, long[] highTable) {
        if ((highTable[pos] & targetPieces) != 0) {
            long next = highTable[pos] & pieces;
            while (next != 0) {
                long contact = lowestBit(next);
                if ((contact & targetPieces) != 0) return true;
                next &= ~highTable[lowestBitPosition(contact)];
                next = nextLowestBit(next);
            }
        }
        return false;
    }

    private static boolean isPositionInAttackLow(int pos, long targetPieces, long pieces, long[] lowTable) {
        if ((lowTable[pos] & targetPieces) != 0) {
            long next = lowTable[pos] & pieces;
            while (next != 0) {
                long contact = highestBit(next);
                if ((contact & targetPieces) != 0) return true;
                next &= ~lowTable[highestBitPosition(contact)];
                next = nextHighestBit(next);
            }
        }
        return false;
    }
}
